#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
explorar_taxones.py
===================
Herramienta de RECONOCIMIENTO previo a la descarga.

Antes de gastar tiempo armando un dataset, queremos saber UNA cosa:
¿cuántas imágenes utilizables existen realmente en iNaturalist para cada
especie/grupo candidato? iNaturalist es ciencia ciudadana: la gente sube
fotos de lo que puede ver y alcanzar. Por eso la fauna de aguas profundas
suele estar casi ausente, y conviene confirmarlo ANTES de comprometerse
con una clase.

Uso:
    python explorar_taxones.py                 # usa la lista de candidatos de abajo
    python explorar_taxones.py "Octopoda" "Asteroidea"   # consulta nombres puntuales

Salida: una tabla con, por cada taxón:
    - el taxon_id resuelto y el nombre que devuelve iNaturalist
      (ojo: si el nombre devuelto NO coincide con el que pediste, la API
       hizo una coincidencia aproximada -> hay que revisar a mano)
    - cantidad de observaciones Research Grade con foto
    - cantidad de observaciones de cualquier grado con foto
"""

import sys
import time
from pyinaturalist import get_taxa, get_observations

# Pausa entre llamadas: iNaturalist pide como máximo ~1 request/segundo.
# Ser respetuoso con la API es parte de hacer las cosas bien (y evita bloqueos).
PAUSA = 1.0

# Candidatos por defecto. Mezclamos:
#  - las dos especies objetivo originales,
#  - sus géneros y familias (para ver si subiendo de nivel aparece algo),
#  - clases morfológicas gruesas que sí suelen aparecer en fondo marino.
CANDIDATOS_DEFAULT = [
    ("Amphitretus pelagicus", "species"),   # pulpo telescopio (objetivo)
    ("Vitreledonella richardi", "species"),  # pulpo de cristal (objetivo)
    ("Amphitretus", "genus"),
    ("Vitreledonella", "genus"),
    ("Octopoda", "order"),        # "pulpo" (clase gruesa)
    ("Asteroidea", "class"),      # estrellas de mar
    ("Holothuroidea", "class"),   # pepinos de mar
    ("Actiniaria", "order"),      # anémonas
    ("Porifera", "phylum"),       # esponjas
    ("Scyphozoa", "class"),       # medusas verdaderas
    ("Decapoda", "order"),        # cangrejos / langostinos
]


def contar_observaciones(taxon_id):
    """Devuelve (research_grade_con_foto, cualquier_grado_con_foto).

    Truco de eficiencia: pedimos per_page=1 porque NO necesitamos las
    observaciones en sí, solo el total. La API devuelve 'total_results'
    aunque traigamos un solo registro. Así gastamos lo mínimo.
    """
    rg = get_observations(taxon_id=taxon_id, quality_grade="research",
                          photos=True, per_page=1)
    time.sleep(PAUSA)
    todo = get_observations(taxon_id=taxon_id, photos=True, per_page=1)
    time.sleep(PAUSA)
    return rg["total_results"], todo["total_results"]


def explorar(candidatos):
    print(f"{'Taxón pedido':32s} {'Nivel':9s} {'id':>8s}  {'nombre iNat':28s} "
          f"{'RG+foto':>8s} {'total+foto':>10s}")
    print("-" * 100)
    for nombre, rank in candidatos:
        try:
            res = get_taxa(q=nombre, rank=rank)
            time.sleep(PAUSA)
        except Exception as e:
            print(f"{nombre:32s} {rank:9s}  ERROR consultando taxón: {e}")
            continue

        if not res["results"]:
            print(f"{nombre:32s} {rank:9s}  -- no se encontró el taxón --")
            continue

        t = res["results"][0]
        tid = t["id"]
        nombre_inat = t["name"]
        # Marcamos con (!) si el nombre devuelto no coincide con lo pedido:
        # significa que iNaturalist devolvió otra cosa parecida.
        alerta = "" if nombre_inat.lower() == nombre.lower() else "  (!) NO COINCIDE"
        rg, todo = contar_observaciones(tid)
        print(f"{nombre:32s} {rank:9s} {tid:>8d}  {nombre_inat:28s} "
              f"{rg:>8d} {todo:>10d}{alerta}")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        # Si pasás nombres por línea de comandos, asumimos rank libre (None).
        candidatos = [(arg, None) for arg in sys.argv[1:]]
    else:
        candidatos = CANDIDATOS_DEFAULT
    explorar(candidatos)
