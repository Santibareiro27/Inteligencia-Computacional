#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
descargar_dataset.py
====================
Descarga imágenes desde iNaturalist según la configuración de un archivo YAML
(por defecto: paraense_fauna.yaml) y deja todo organizado y documentado para
que el experimento sea REPRODUCIBLE (requisito explícito de la cátedra).

Qué hace, paso a paso:
  1. Lee la configuración (clases, tope por clase, grado de calidad, etc.).
  2. Para cada clase resuelve el taxon_id a partir del nombre científico
     (o usa el que le fijaste a mano) y VERIFICA que el nombre coincida.
  3. Pide a la API observaciones con foto, filtrando por grado de calidad
     (típicamente 'research' = validadas por la comunidad), paginando.
  4. Descarga las imágenes a data/crudo/<carpeta>/ en el tamaño elegido.
  5. Escribe un manifiesto CSV con la procedencia de CADA imagen
     (id, autor, licencia, url, fecha, lugar) -> trazabilidad y atribución.

Requisitos:  pip install pyinaturalist requests pyyaml
Uso:         python descargar_dataset.py [ruta_al_yaml]
"""

import csv
import os
import sys
import time
import requests
import yaml
from pyinaturalist import get_taxa, get_observations

# iNaturalist sirve las fotos en varios tamaños cambiando una palabra en la URL.
# La URL que devuelve la API termina en .../square.jpg ; reemplazamos 'square'.
TAMANOS_VALIDOS = {"square", "small", "medium", "large", "original"}

# User-Agent identificable: buena práctica (y cortesía) al pegarle a una API pública.
HEADERS = {"User-Agent": "IC415-UNaM-proyecto-fauna-marina/1.0"}


def cargar_config(ruta):
    with open(ruta, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def resolver_taxon(nombre_cientifico, taxon_id_fijo, pausa):
    """Devuelve un taxon_id confiable. Si el nombre devuelto por iNaturalist
    no coincide con el pedido, AVISA: puede ser una coincidencia aproximada."""
    if taxon_id_fijo:
        return taxon_id_fijo
    res = get_taxa(q=nombre_cientifico, rank="species")
    time.sleep(pausa)
    if not res["results"]:
        raise ValueError(f"No se encontró el taxón '{nombre_cientifico}' en iNaturalist.")
    t = res["results"][0]
    if t["name"].lower() != nombre_cientifico.lower():
        print(f"   (!) ATENCIÓN: pediste '{nombre_cientifico}' pero iNaturalist "
              f"devolvió '{t['name']}' (id {t['id']}). Verificá a mano y, si hace "
              f"falta, fijá el taxon_id correcto en el YAML.")
    return t["id"]


def url_en_tamano(url_square, tamano):
    """Convierte la URL .../square.jpg al tamaño deseado."""
    if tamano not in TAMANOS_VALIDOS:
        tamano = "medium"
    return url_square.replace("square.", f"{tamano}.")


def descargar_clase(clase, cfg, escritor_csv):
    carpeta = clase["carpeta"]
    nombre_cientifico = clase["nombre_cientifico"]
    destino = os.path.join(cfg["descarga"]["directorio_salida"], carpeta)
    os.makedirs(destino, exist_ok=True)

    tope = cfg["descarga"]["imagenes_por_clase"]
    grado = cfg["descarga"]["grado_calidad"]
    tamano = cfg["descarga"].get("tamano_imagen", "medium")
    pausa = cfg["descarga"].get("pausa_segundos", 1.0)
    # Cuántas fotos tomar por observación. 1 maximiza la DIVERSIDAD:
    # varias fotos de la misma observación suelen ser casi idénticas
    # (mismo individuo, misma sesión) y, si caen repartidas entre train y
    # test, "filtran" información y inflan falsamente la métrica.
    fotos_por_obs = cfg["descarga"].get("fotos_por_observacion", 1)

    print(f"\n=== Clase '{carpeta}' ({nombre_cientifico}) ===")
    taxon_id = resolver_taxon(nombre_cientifico, clase.get("taxon_id"), pausa)
    print(f"   taxon_id usado: {taxon_id} | grado: {grado} | tope: {tope}")

    descargadas = 0
    pagina = 1
    while descargadas < tope:
        resp = get_observations(taxon_id=taxon_id, quality_grade=grado,
                                photos=True, per_page=200, page=pagina)
        time.sleep(pausa)
        observaciones = resp["results"]
        if not observaciones:
            print(f"   No hay más observaciones. Total disponible agotado.")
            break

        for obs in observaciones:
            if descargadas >= tope:
                break
            for ph in obs["photos"][:fotos_por_obs]:
                if descargadas >= tope:
                    break
                url = url_en_tamano(ph["url"], tamano)
                nombre_archivo = f"{obs['id']}_{ph['id']}.jpg"
                ruta_local = os.path.join(destino, nombre_archivo)
                try:
                    r = requests.get(url, headers=HEADERS, timeout=30)
                    r.raise_for_status()
                    with open(ruta_local, "wb") as fimg:
                        fimg.write(r.content)
                except Exception as e:
                    print(f"   ! Falló {url}: {e}")
                    continue

                # Registramos la procedencia para reproducibilidad + atribución.
                escritor_csv.writerow({
                    "clase": carpeta,
                    "nombre_cientifico": nombre_cientifico,
                    "taxon_id": taxon_id,
                    "observation_id": obs["id"],
                    "photo_id": ph["id"],
                    "licencia": ph.get("license_code"),
                    "autor": (obs.get("user") or {}).get("login"),
                    "fecha_obs": str(obs.get("observed_on")),
                    "lugar": obs.get("place_guess"),
                    "url": url,
                    "archivo_local": os.path.join(carpeta, nombre_archivo),
                })
                descargadas += 1
                if descargadas % 25 == 0:
                    print(f"   ... {descargadas}/{tope}")
                time.sleep(pausa)
        pagina += 1

    print(f"   LISTO: {descargadas} imágenes en {destino}")
    return descargadas


def main():
    ruta_yaml = sys.argv[1] if len(sys.argv) > 1 else "paraense_fauna.yaml"
    cfg = cargar_config(ruta_yaml)

    salida = cfg["descarga"]["directorio_salida"]
    os.makedirs(salida, exist_ok=True)
    ruta_manifiesto = os.path.join(salida, "manifiesto.csv")

    campos = ["clase", "nombre_cientifico", "taxon_id", "observation_id",
              "photo_id", "licencia", "autor", "fecha_obs", "lugar",
              "url", "archivo_local"]

    total = 0
    with open(ruta_manifiesto, "w", newline="", encoding="utf-8") as fcsv:
        escritor = csv.DictWriter(fcsv, fieldnames=campos)
        escritor.writeheader()
        for clase in cfg["clases"]:
            total += descargar_clase(clase, cfg, escritor)

    print(f"\n========================================")
    print(f"Total descargado: {total} imágenes")
    print(f"Manifiesto de procedencia: {ruta_manifiesto}")


if __name__ == "__main__":
    main()
